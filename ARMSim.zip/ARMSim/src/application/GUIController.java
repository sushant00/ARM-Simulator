package application;

import java.io.IOException;
import java.io.Serializable;
import java.net.URL;
import java.util.ArrayList;
import java.util.ResourceBundle;

import javafx.animation.Interpolator;
import javafx.animation.PathTransition;
import javafx.animation.Timeline;
import javafx.event.ActionEvent;
import javafx.event.Event;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.ColorPicker;
import javafx.scene.control.Label;
import javafx.scene.control.MenuButton;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.control.Tooltip;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.image.ImageView;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.GridPane;
import javafx.scene.paint.Color;
import javafx.scene.shape.Circle;
import javafx.stage.Stage;
import javafx.util.Duration;

public class GUIController  implements Initializable {	
	ARMSim arm;
	
	@FXML
	private Button btnStop, btnRun, btnReload, btnStepInto;
	
	@FXML
	private TextField fileName;
	
	@FXML
	private TextArea txtRegister, txtStack, txtOutputView, txtMemView, consoleOutput, consoleInput;
	
	@FXML
	public void run(){
		arm.simulate();
	}
	@FXML
	public void stepInto(){
		int a = arm.nextStep();
		txtRegister.setText(arm.getRegisterStatus());
		txtStack.setText(arm.getMemoryStatus());
		txtStack.setScrollTop(Double.MAX_VALUE);
	}
	@FXML
	public void reload(){
    	btnRun.setDisable(false);
    	btnStop.setDisable(false);
    	btnStepInto.setDisable(false);
		arm.init();
		String file = fileName.getText();
		if(file.equals("")){
			file = "input.mem";
		}
		arm.loadMem(file);
	}
	@FXML
	public void stop(){
		arm.swi_exit();
	}
	
	 
    @Override
    public void initialize(URL location, ResourceBundle resources) {   
    	arm = new ARMSim();
    	btnRun.setDisable(true);
    	btnStop.setDisable(true);
    	btnStepInto.setDisable(true);
    	txtRegister.setEditable(false);
    	txtStack.setEditable(false);
    	//txtMemView.setEditable(false);
    	txtOutputView.setEditable(false);
		txtStack.setScrollTop(Double.MAX_VALUE);
    }
}